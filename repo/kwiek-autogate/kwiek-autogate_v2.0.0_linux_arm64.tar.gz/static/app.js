const API_BASE = '/api/relays';
let isPolling = false;
let pollingInterval = null;
let currentHwid = '';

// DOM Elements
const connectionStatus = document.getElementById('connection-status');
const relayGrid = document.getElementById('relay-grid');
const btnAllOff = document.getElementById('btn-all-off');
const btnAllOn = document.getElementById('btn-all-on');

// Elements Licenca & Modal
const licenseBanner = document.getElementById('license-banner');
const licenseStatusTitle = document.getElementById('license-status-title');
const licenseStatusDesc = document.getElementById('license-status-desc');
const licenseModal = document.getElementById('license-modal');
const btnOpenLicenseModal = document.getElementById('btn-open-license-modal');
const btnCloseLicenseModal = document.getElementById('btn-close-license-modal');
const btnManageLicense = document.getElementById('btn-manage-license');
const modalHwidText = document.getElementById('modal-hwid-text');
const btnCopyHwid = document.getElementById('btn-copy-hwid');
const inputLicenseKey = document.getElementById('input-license-key');
const btnSaveLicense = document.getElementById('btn-save-license');
const licenseFeedbackMsg = document.getElementById('license-feedback-msg');
const footerHwid = document.getElementById('footer-hwid');
const footerClientName = document.getElementById('footer-client-name');
const btnCheckUpdate = document.getElementById('btn-check-update');

// Fetch and render the status of all relays
async function updateRelays() {
    try {
        const response = await fetch(API_BASE);
        if (!response.ok) throw new Error('API Response Error');
        
        const relays = await response.json();
        renderRelays(relays);
        setConnected(true);
    } catch (error) {
        console.error('Failed to fetch relay status:', error);
        setConnected(false);
    }
}

// Render the grid cards dynamically
function renderRelays(relays) {
    relayGrid.innerHTML = '';
    
    relays.forEach(relay => {
        const card = document.createElement('div');
        card.className = `relay-card ${relay.state ? 'active' : ''}`;
        card.id = `relay-card-${relay.id}`;
        
        card.innerHTML = `
            <div class="relay-card-header">
                <div class="relay-info">
                    <span class="relay-name">${relay.name}</span>
                    <span class="relay-gpio">GPIO ${relay.gpio}</span>
                </div>
                <span class="status-badge">${relay.state ? 'LIGADO' : 'DESLIGADO'}</span>
            </div>
            
            <div class="switch-wrapper">
                <button class="btn-pulse" onclick="pulseRelay(${relay.id})">
                     Pulso
                </button>
                
                <label class="switch">
                    <input type="checkbox" id="toggle-input-${relay.id}" ${relay.state ? 'checked' : ''} onchange="toggleRelay(${relay.id}, this.checked)">
                    <span class="slider"></span>
                </label>
            </div>
        `;
        
        relayGrid.appendChild(card);
    });
}

// Toggle command
async function toggleRelay(id, state) {
    const card = document.getElementById(`relay-card-${id}`);
    const badge = card?.querySelector('.status-badge');
    const action = state ? 'turn_on' : 'turn_off';
    
    if (badge) {
        card.classList.toggle('active', state);
        badge.textContent = state ? 'LIGADO' : 'DESLIGADO';
    }
    
    try {
        const response = await fetch(`${API_BASE}/${id}/${action}`, { method: 'POST' });
        if (!response.ok) {
            const err = await response.json();
            alert(`Acao nao autorizada: ${err.detail || 'Falha na licenca'}`);
            updateRelays();
            checkLicense();
            return;
        }
        const data = await response.json();
        updateRelayCardState(data);
    } catch (error) {
        console.error(`Failed to toggle relay ${id}:`, error);
        updateRelays();
    }
}

// Pulse command
async function pulseRelay(id) {
    try {
        const response = await fetch(`${API_BASE}/${id}/pulse`, { method: 'POST' });
        if (!response.ok) {
            const err = await response.json();
            alert(`Acao nao autorizada: ${err.detail || 'Falha na licenca'}`);
            checkLicense();
            return;
        }
        
        const card = document.getElementById(`relay-card-${id}`);
        const toggle = document.getElementById(`toggle-input-${id}`);
        const badge = card?.querySelector('.status-badge');
        
        if (card && toggle && badge) {
            card.classList.add('active');
            toggle.checked = true;
            badge.textContent = 'LIGADO';
        }
        setTimeout(updateRelays, 800);
    } catch (error) {
        console.error(`Failed to pulse relay ${id}:`, error);
    }
}

function updateRelayCardState(relay) {
    const card = document.getElementById(`relay-card-${relay.id}`);
    if (!card) return;
    
    const toggle = document.getElementById(`toggle-input-${relay.id}`);
    const badge = card.querySelector('.status-badge');
    
    if (relay.state) {
        card.classList.add('active');
        if (toggle) toggle.checked = true;
        badge.textContent = 'LIGADO';
    } else {
        card.classList.remove('active');
        if (toggle) toggle.checked = false;
        badge.textContent = 'DESLIGADO';
    }
}

async function setAllRelays(state) {
    try {
        const response = await fetch(API_BASE);
        const relays = await response.json();
        const action = state ? 'turn_on' : 'turn_off';
        
        await Promise.all(relays.map(relay => 
            fetch(`${API_BASE}/${relay.id}/${action}`, { method: 'POST' })
        ));
        
        updateRelays();
    } catch (error) {
        console.error(`Failed to turn all relays ${state ? 'ON' : 'OFF'}:`, error);
    }
}

function setConnected(connected) {
    if (connected) {
        connectionStatus.classList.add('connected');
        connectionStatus.querySelector('.status-text').textContent = 'Online';
    } else {
        connectionStatus.classList.remove('connected');
        connectionStatus.querySelector('.status-text').textContent = 'Offline';
    }
}

// Fetch version and license
async function checkLicense() {
    try {
        const res = await fetch('/api/system/license');
        if (res.ok) {
            const data = await res.json();
            currentHwid = data.hardware_id;
            footerHwid.textContent = currentHwid;
            modalHwidText.textContent = currentHwid;
            document.getElementById('app-version').textContent = `v${data.current_version}`;
            
            if (data.license_key) {
                inputLicenseKey.value = data.license_key;
            }
            
            if (data.is_valid) {
                licenseBanner.style.display = 'none';
                if (data.payload && data.payload.client) {
                    footerClientName.textContent = `Cliente: ${data.payload.client}`;
                }
            } else {
                licenseBanner.style.display = 'flex';
                licenseStatusTitle.textContent = 'Dispositivo Nao Ativado ou Licenca Expirada';
                licenseStatusDesc.textContent = data.reason || 'Acionamentos bloqueados ate validacao da contrachave.';
            }
        }
    } catch (err) {
        console.error('Falha ao checar licenca:', err);
    }
}

// Salvar / Ativar Contrachave
async function saveLicense() {
    const key = inputLicenseKey.value.trim();
    if (!key) {
        licenseFeedbackMsg.className = 'feedback-msg error';
        licenseFeedbackMsg.textContent = 'Por favor, insira a contrachave.';
        return;
    }
    
    licenseFeedbackMsg.className = 'feedback-msg';
    licenseFeedbackMsg.textContent = 'Validando chave...';
    
    try {
        const res = await fetch('/api/system/license', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ license_key: key })
        });
        
        const data = await res.json();
        if (res.ok) {
            licenseFeedbackMsg.className = 'feedback-msg success';
            licenseFeedbackMsg.textContent = 'Licenca ativada com sucesso!';
            setTimeout(() => {
                licenseModal.style.display = 'none';
                checkLicense();
                updateRelays();
            }, 1200);
        } else {
            licenseFeedbackMsg.className = 'feedback-msg error';
            licenseFeedbackMsg.textContent = data.detail || 'Chave rejeitada.';
        }
    } catch (e) {
        licenseFeedbackMsg.className = 'feedback-msg error';
        licenseFeedbackMsg.textContent = 'Erro ao contatar servidor.';
    }
}

// Verificar e Acionar Atualizacoes
async function checkUpdates() {
    btnCheckUpdate.textContent = ' Verificando...';
    try {
        const res = await fetch('/api/system/update-status');
        const data = await res.json();
        
        if (data.update_available) {
            const mensagemAviso = 
                ` NOVA VERSAO DISPONIVEL: v${data.target_version}\n\n` +
                `Versao atualmente instalada: v${data.current_version}\n` +
                `Notas: ${data.notes || 'Melhorias de desempenho e estabilidade'}\n\n` +
                ` ATENCAO E AVISO IMPORTANTE:\n` +
                ` O aplicativo sera reiniciado para aplicar a atualizacao.\n` +
                ` Durante a reinicializacao, TODOS OS RELES retornarao estritamente no estado DESLIGADO por seguranca.\n\n` +
                `Deseja aplicar a atualizacao agora mesmo?\n` +
                `[ OK ] = Atualizar agora\n` +
                `[ Cancelar ] = Desistir e atualizar em outro momento`;

            const confirmUpdate = confirm(mensagemAviso);
            
            if (confirmUpdate) {
                const triggerRes = await fetch('/api/system/trigger-update', { method: 'POST' });
                if (triggerRes.ok) {
                    btnCheckUpdate.textContent = ' Atualizando...';
                    btnCheckUpdate.disabled = true;

                    // Notifica o usuario e inicia a espera com reload automatico
                    alert(
                        ' Atualizacao iniciada em segundo plano!\n\n' +
                        'O sistema esta baixando os arquivos e reiniciara o servico.\n' +
                        'Esta pagina sera recarregada automaticamente assim que o portao estiver pronto.'
                    );

                    // Desativa o polling normal temporariamente
                    if (pollingInterval) clearInterval(pollingInterval);

                    // Aguarda 6 segundos para o servico iniciar o processo de restart e comeca a sondagem no /api/health
                    setTimeout(() => {
                        let attempts = 0;
                        const reconnectTimer = setInterval(async () => {
                            attempts++;
                            try {
                                const healthRes = await fetch('/api/health', { cache: 'no-store' });
                                if (healthRes.ok) {
                                    clearInterval(reconnectTimer);
                                    window.location.reload(); // Recarregamento 100% automatico!
                                }
                            } catch (err) {
                                // Servidor ainda reiniciando, continua sondando
                            }

                            // Limite de seguranca de 45 tentativas (90 segundos)
                            if (attempts > 45) {
                                clearInterval(reconnectTimer);
                                window.location.reload();
                            }
                        }, 2000);
                    }, 6000);
                } else {
                    alert('Falha ao disparar processo de atualizacao.');
                    btnCheckUpdate.textContent = ' Verificar Atualizacoes';
                    btnCheckUpdate.disabled = false;
                }
            } else {
                console.log('Atualizacao cancelada pelo usuario. Pode ser realizada em outro momento.');
                btnCheckUpdate.textContent = ' Verificar Atualizacoes';
            }
        } else {
            alert(`Seu sistema esta atualizado na versao autorizada (v${data.current_version}).`);
            btnCheckUpdate.textContent = ' Verificar Atualizacoes';
        }
    } catch (e) {
        alert('Nao foi possivel verificar atualizacoes no momento.');
        btnCheckUpdate.textContent = ' Verificar Atualizacoes';
    }
}

// Event Listeners
btnAllOff.addEventListener('click', () => setAllRelays(false));
btnAllOn.addEventListener('click', () => setAllRelays(true));
btnOpenLicenseModal.addEventListener('click', () => { licenseModal.style.display = 'flex'; });
btnManageLicense.addEventListener('click', () => { licenseModal.style.display = 'flex'; });
btnCloseLicenseModal.addEventListener('click', () => { licenseModal.style.display = 'none'; });
btnSaveLicense.addEventListener('click', saveLicense);
btnCheckUpdate.addEventListener('click', checkUpdates);

btnCopyHwid.addEventListener('click', () => {
    navigator.clipboard.writeText(currentHwid);
    btnCopyHwid.textContent = 'Copiado!';
    setTimeout(() => { btnCopyHwid.textContent = 'Copiar'; }, 2000);
});

// Inicializacao
updateRelays();
checkLicense();
pollingInterval = setInterval(updateRelays, 2500);
