#!/bin/bash
# -----------------------------------------------------------------------------
# install_supervisor.sh
# Instalador oficial e universal do Kwiek Autogate Supervisor (Rust)
# - Baixa tudo diretamente do GitHub via HTTPS (curl / wget)
# - Nao requer clonar repositorio, nem Git, nem compiladores no Pi
# - Pode ser executado com um unico comando curl | bash
# - Registra o kwiek-supervisor permanente no systemd
# -----------------------------------------------------------------------------

set -e

TARGET_DIR="/opt/kwiek-autogate"
SERVICE_NAME="kwiek-supervisor"
REPO_URL="https://raw.githubusercontent.com/eijuito/kwiek-autogate/rust-dist"

echo "=== Instalando Kwiek Autogate Supervisor (Download Direto do GitHub) ==="
echo "Destino: $TARGET_DIR"

# 1. Parar servicos anteriores caso estejam rodando
sudo systemctl stop kwiek-supervisor.service 2>/dev/null || true
sudo systemctl stop kwiek-autogate.service 2>/dev/null || true
sudo systemctl disable kwiek-autogate.service 2>/dev/null || true
sudo killall -9 kwiek-supervisor kwiek-worker 2>/dev/null || true

# 2. Criar a estrutura de diretorios de producao
sudo mkdir -p "$TARGET_DIR/static"
sudo mkdir -p "$TARGET_DIR/templates"

# 3. Baixar os binarios nativos ARM64 via HTTPS
echo "Baixando kwiek-supervisor..."
sudo curl -sSL -f "$REPO_URL/kwiek-supervisor" -o "$TARGET_DIR/kwiek-supervisor"
sudo chmod +x "$TARGET_DIR/kwiek-supervisor"

echo "Baixando kwiek-worker..."
sudo curl -sSL -f "$REPO_URL/kwiek-worker" -o "$TARGET_DIR/kwiek-worker"
sudo chmod +x "$TARGET_DIR/kwiek-worker"

# 4. Baixar arquivos estaticos (HTML, CSS, JS)
echo "Baixando templates e arquivos web..."
sudo curl -sSL -f "$REPO_URL/templates/index.html" -o "$TARGET_DIR/templates/index.html"
sudo curl -sSL -f "$REPO_URL/templates/logs.html" -o "$TARGET_DIR/templates/logs.html"
sudo curl -sSL -f "$REPO_URL/templates/config_editor.html" -o "$TARGET_DIR/templates/config_editor.html"
sudo curl -sSL -f "$REPO_URL/templates/wifi_setup.html" -o "$TARGET_DIR/templates/wifi_setup.html"
sudo curl -sSL -f "$REPO_URL/static/style.css" -o "$TARGET_DIR/static/style.css"
sudo curl -sSL -f "$REPO_URL/static/app.js" -o "$TARGET_DIR/static/app.js"

# 5. Se nao existir config.json, cria o padrao
if [ ! -f "$TARGET_DIR/config.json" ]; then
    echo "Criando config.json inicial..."
    cat <<EOF | sudo tee "$TARGET_DIR/config.json" > /dev/null
{
  "relays": {
    "1": { "name": "Relay 1 (Gate)", "gpio": 26, "active_high": false },
    "2": { "name": "Relay 2 (Light)", "gpio": 20, "active_high": false },
    "3": { "name": "Relay 3", "gpio": 21, "active_high": false }
  },
  "buttons": {
    "1": { "gpio": 5, "pull_up": true, "relay_id": 1, "mode": "pulse" },
    "2": { "gpio": 6, "pull_up": true, "relay_id": 2, "mode": "pulse" },
    "3": { "gpio": 12, "pull_up": true, "relay_id": 3, "mode": "pulse" },
    "4": { "gpio": 13, "pull_up": true, "relay_id": 1, "mode": "pulse" }
  },
  "default_pulse_duration": 3.0,
  "debounce_time_s": 0.1,
  "enable_startup_self_test": false,
  "auth_username": "porta",
  "auth_password": "127952",
  "version": "2.0.0",
  "github_repo": "eijuito/kwiek-autogate",
  "license_key": ""
}
EOF
fi

# 6. Configurar o servico permanente no systemd
echo "Registrando servico kwiek-supervisor no systemd..."
cat <<EOF | sudo tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null
[Unit]
Description=Kwiek Autogate Supervisor & Hardware Watchdog (Rust)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET_DIR
ExecStart=$TARGET_DIR/kwiek-supervisor
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

# 7. Recarregar e iniciar o servico permanente
sudo systemctl daemon-reload
sudo systemctl enable ${SERVICE_NAME}.service
sudo systemctl restart ${SERVICE_NAME}.service

echo ""
echo "=== Instalacao Concluida com Sucesso! ==="
echo "Status do servico permanente:"
sudo systemctl status ${SERVICE_NAME}.service --no-pager

