# 0itonexus

Hub e barramento central de comunicação, mensageria e telemetria do **Ecossistema 0ito**.

---

## Visão Geral
O `0itonexus` é o componente central de mensageria assíncrona, orquestração de eventos e telemetria em tempo real entre os 4 pilares do ecossistema:
- **`0itotrade`**: Eventos de ordens, trades, alertas de risco e consolidação de ticks.
- **`0itoiot`**: Telemetria de dispositivos de borda, sensores e acionamento seguro de atuadores.
- **`0itocore`**: Supervisão de ciclo de vida de daemons, auditoria e health-checks corporativos.
- **`0itomedia`**: Claim-checks de produção audiovisual, triggers de publicação e distribuição de conteúdo.

---

## Arquitetura e Diretrizes
- **Soberania Tecnológica**: 100% Rust Nativo (Tokio + Axum + Serde). Zero scripts em Python ou linguagens alienígenas (Regra 6 do `AGENTS.md`).
- **Engenharia X-DD**: Desenvolvimento guiado estritamente por especificações executáveis (`docs/specs/SPEC-01-nexus-core.md`), contratos tipados (`CDD`) e testes automatizados (`TDD`).
- **Resiliência e Desacoplamento**: Bounded channels com proteção contra esgotamento de memória e suporte nativo a stream de Server-Sent Events (SSE).
