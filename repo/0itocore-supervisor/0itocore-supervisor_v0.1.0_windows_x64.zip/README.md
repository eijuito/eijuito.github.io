# 0itocore-supervisor

[![Rust](https://img.shields.io/badge/language-Rust_1.78+-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-Proprietary_0ito-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Linux_|_Windows-lightgrey.svg)](#instalação-rápida-em-comando-único)
[![Security](https://img.shields.io/badge/security-Ed25519_|_KDBX_v4-green.svg)](docs/architecture.md)

Orquestrador Soberano de Ciclo de Vida, Catálogo de Plugins, Supervisão de Processos e Gestão de Licenças do **Ecossistema 0ito**.

---

## 📚 Documentação Oficial

Para navegar detalhadamente em todos os aspectos do projeto, acesse os guias especializados:

| Guia | Descrição |
| :--- | :--- |
| 🚀 **[Como Iniciar (Quickstart)](docs/getting-started.md)** | Primeiros passos em 3 minutos, diagnóstico de saúde e primeiro serviço monitorado. |
| 📦 **[Procedimentos de Instalação](docs/installation.md)** | Guia completo de instalação para Linux e Windows, atualização atômica, rollback e manutenção. |
| 📖 **[Como Usar (Manual de Operação)](docs/usage.md)** | Linha de comando (CLI), configuração de `config.json`, endpoints da API REST e monitoramento. |
| 🏛️ **[Explicação da Arquitetura](docs/architecture.md)** | Modelo de segurança em dois modos (Nó vs Autoridade), motor assíncrono e malha de supervisores. |

---

## ⚡ Instalação Rápida em Comando Único

### 🐧 No Linux (Ubuntu, Debian, CentOS, Raspberry Pi)
Execute no terminal como superusuário:
```bash
# Instalação Oficial em Produção (/opt/0ito/0itocore/0itocore-supervisor/ - porta 8000)
curl -fsSL https://eijuito.github.io/repo/0itocore-supervisor/install.sh | sudo bash

# Instalação em Desenvolvimento (/opt/0itodev/0itocore/0itocore-supervisor/ - porta 18000)
curl -fsSL https://eijuito.github.io/repo/0itocore-supervisor/install.sh | sudo bash -s -- --dev

# Espelho de Contingência Direto (caso o Pages esteja em deploy)
curl -fsSL https://raw.githubusercontent.com/eijuito/eijuito.github.io/main/repo/0itocore-supervisor/install.sh | sudo bash
```
> Valida conectividade, detecta arquitetura (`x86_64` ou `arm64`), verifica integridade com `SHA256SUMS`, instala em `/opt/{0ito,0itodev}/0itocore/0itocore-supervisor/` e ativa o daemon persistente no `systemd` (`0itocore-supervisor.service`).

---

### 🪟 No Windows (Notebook VAIO, Windows 10/11 x64)
Abra o **PowerShell como Administrador** e execute:
```powershell
# Instalação Oficial em Produção (C:\0ito\0itocore\0itocore-supervisor\ - porta 8000)
powershell -ExecutionPolicy Bypass -Command "irm https://eijuito.github.io/repo/0itocore-supervisor/install.ps1 | iex"

# Instalação em Desenvolvimento (C:\0itodev\0itocore\0itocore-supervisor\ - porta 18000)
powershell -ExecutionPolicy Bypass -Command "$Dev = $true; irm https://eijuito.github.io/repo/0itocore-supervisor/install.ps1 | iex"

# Espelho Direto de Contingência
powershell -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/eijuito/eijuito.github.io/main/repo/0itocore-supervisor/install.ps1 | iex"
```
> Valida conformidade 64-bit, baixa `0itocore-supervisor.exe` com validação de hash, instala na hierarquia canônica `{0ITO_HOME}\0itocore\0itocore-supervisor\`, adiciona o binário ao PATH e registra a inicialização automática no boot via Tarefa Agendada do Windows (`RunLevel Highest`).

---

## 🔎 Verificação Rápida de Saúde (Health Check)

Após iniciar o daemon em qualquer plataforma, verifique a prontidão:

```bash
# Terminal Linux / macOS (Produção: :8000 | Dev: :18000)
curl -s http://127.0.0.1:8000/health

# Windows PowerShell
Invoke-RestMethod http://127.0.0.1:8000/health
```

**Resposta:**
```json
{
  "status": "ok",
  "service": "0itocore-supervisor",
  "version": "0.1.0"
}
```

---

## 📂 Estrutura Oficial de Diretórios e Orquestração Multi-Pilares

O supervisor gerencia o ciclo de vida e instâncias de aplicações distribuídas em **todos os 4 pilares do ecossistema 0ito**:

```
{0ITO_HOME}/                                [Linux: /opt/0ito/ | Windows: C:\0ito\]
├── 0itocore/                               # Pilar de Infraestrutura & Serviços Centrais
│   └── 0itocore-supervisor/                # O próprio Supervisor
│       ├── bin/                            # Binário ativo e backup (.old) para rollback
│       ├── config/                         # config.json (portas, ambiente, processos)
│       └── logs/                           # Logs operacionais do daemon
├── 0itotrade/                               # Pilar de Trading Algorítmico
│   └── 0itotrade-mt5service/
│       ├── bin/                            # Binário compartilhado
│       └── instances/                      # Instâncias isoladas por conta/estratégia
│           └── acc_109283/                 # config.json, data/ e logs/
├── 0itoiot/                                 # Pilar de Automação & IoT
│   └── 0itoiot-kwiek-autogate/             # instances/ isoladas por portão/controlador
└── 0itomedia/                               # Pilar de Mídia & YouTube
    └── 0itomedia-poderedominio/            # instances/ isoladas por canal/pipeline
```

---

## 🛡️ Os 4 Pilares de Engenharia do Supervisor
1. **Soberania Tecnológica**: Desenvolvido 100% em Rust nativo para máxima eficiência e consumo de RAM inferior a 15 MB.
2. **Segregação de Segurança**: O **Modo Nó** padrão opera sem chaves privadas e sem cofre em VPSs remotas; o **Modo Autoridade** é restrito ao ambiente de desenvolvimento seguro.
3. **Imutabilidade e Preservação de Dados**: Atualizações de versão do supervisor ou de plugins nunca modificam nem apagam configurações existentes ou pastas de instâncias.
4. **Malha Integrada**: Conecta-se nativamente ao barramento **`0itonexus`** para streaming de telemetria e coordenação distribuída.
