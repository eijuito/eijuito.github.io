# 0itocore-supervisor

Orquestrador Soberano de Ciclo de Vida, Supervisão de Processos e Gestão de Licenças do **Ecossistema 0ito**.

---

## Visão Geral
O `0itocore-supervisor` é o daemon central responsável por gerenciar a execução, saúde, atualizações atômicas e resiliência de todos os serviços do ecossistema:
- **`0itonexus`**: Barramento de telemetria e mensageria.
- **`0itoiot-kwiek-autogate`**: Firmware e controle de acesso de portões.
- **`0itotrade`**: Robôs de trading e coletores de mercado financeiro.
- **`0itocore-runner-financeimport`**: Importação financeira via Open Finance (Pluggy).

---

## Arquitetura de Segurança em Dois Modos
1. **Modo Nó (Worker / Remoto)**:
   - Instalado em servidores Proxmox (`server-miku`), VPSs na nuvem (Oracle, Hostinger) e Raspberry Pis.
   - Ultra-leve (< 10 MB de RAM), sem cofre de licenças e sem chaves privadas mestras.
   - Gerencia processos locais, monitora endpoints `/health` e reinicia serviços em caso de crash.
2. **Modo Autoridade (Local Seguro)**:
   - Ativado sob demanda exclusivamente no computador de desenvolvimento pessoal.
   - Gerencia o cofre criptografado `.kdbx` (KDBX v4 / Argon2id).
   - Emite e renova licenças Ed25519 para clientes e certificados mTLS para VPSs.
