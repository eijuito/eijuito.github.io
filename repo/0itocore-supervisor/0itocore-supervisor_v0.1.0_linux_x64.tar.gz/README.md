# 0itocore-supervisor

Orquestrador Soberano de Ciclo de Vida, Catálogo de Plugins, Supervisão de Processos e Gestão de Licenças do **Ecossistema 0ito**.

---

## Instalação Rápida e Facilitada (Comando Único)

### 🐧 No Linux (Ubuntu, Debian, CentOS, Raspberry Pi)
Execute no terminal com privilégios de superusuário:
```bash
curl -fsSL https://eijuito.github.io/repo/0itocore-supervisor/install.sh | sudo bash
```
> O instalador verifica conectividade, valida arquitetura (`x86_64` ou `arm64`), baixa os artefatos com checagem criptográfica SHA256, instala em `/opt/0itocore-supervisor/` e ativa o serviço daemon persistente no `systemd` (`0itocore-supervisor.service`).

**Comandos Úteis de Manutenção no Linux:**
```bash
sudo /opt/0itocore-supervisor/bin/0itocore-supervisor --status   # Verifica status
sudo systemctl status 0itocore-supervisor                       # Status do serviço
sudo journalctl -u 0itocore-supervisor -f                       # Logs em tempo real
curl http://127.0.0.1:8000/health                               # Health check HTTP
```

---

### 🪟 No Windows (Notebook VAIO, Windows 10/11 x64)
Abra o **PowerShell como Administrador** e execute:
```powershell
powershell -ExecutionPolicy Bypass -Command "irm https://eijuito.github.io/repo/0itocore-supervisor/install.ps1 | iex"
```
> O instalador valida os requisitos do sistema, baixa `0itocore-supervisor.exe` com validação de hash SHA256, instala em `C:\0itocore-supervisor\`, adiciona o binário ao PATH e registra a inicialização automática no boot via Tarefa Agendada do Windows (`RunLevel Highest`).

**Comandos Úteis de Manutenção no Windows:**
```powershell
0itocore-supervisor.exe --version                               # Versão instalada
Get-ScheduledTask -TaskName 0itocore-supervisor                 # Status da tarefa agendada
Invoke-RestMethod http://127.0.0.1:8000/health                  # Health check HTTP
```

---

## Visão Geral
O `0itocore-supervisor` é o daemon central responsável por gerenciar a execução, saúde, atualizações atômicas e resiliência de todos os serviços do ecossistema:
- **`0itonexus`**: Barramento de telemetria e mensageria distribuída.
- **`0itoiot-kwiek-autogate`**: Firmware e controle de acesso de portões.
- **`0itotrade`**: Robôs de trading e coletores de mercado financeiro (`mt5service`).
- **`0itocore-runner-financeimport`**: Importação financeira via Open Finance (Pluggy).

---

## Arquitetura de Segurança em Dois Modos
1. **Modo Nó (Worker / Remoto)**:
   - Instalado em servidores Proxmox (`server-miku`), VPSs na nuvem (Oracle, Hostinger) e Raspberry Pis.
   - Ultra-leve (< 15 MB de RAM), sem cofre de licenças e sem chaves privadas mestras.
   - Gerencia processos locais, monitora endpoints `/health` e reinicia serviços em caso de crash.
2. **Modo Autoridade (Local Seguro)**:
   - Ativado sob demanda exclusivamente no computador de desenvolvimento pessoal / notebook seguro.
   - Gerencia o cofre criptografado de licenças.
   - Emite e renova licenças assinadas com Ed25519 para clientes e nós remotos.

---

## Estrutura Oficial de Diretórios
```
[Linux: /opt/0itocore-supervisor/ | Windows: C:\0itocore-supervisor\]
├── bin/
│   ├── 0itocore-supervisor[.exe]       <- Binário ativo em execução
│   └── 0itocore-supervisor[.exe].old   <- Cópia de segurança para rollback atômico
├── config/
│   └── config.json                     <- Configuração e portas
├── data/                               <- Estado e persistência de instâncias
├── plugins/                            <- Binários e manifestos do catálogo baixados
├── instances/                          <- Pastas isoladas de cada processo em execução
└── logs/                               <- Logs operacionais
```
