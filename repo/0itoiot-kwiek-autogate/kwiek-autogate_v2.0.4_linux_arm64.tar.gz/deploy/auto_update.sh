#!/bin/bash
# -----------------------------------------------------------------------------
# auto_update.sh
# Atualizador resiliente e seguro para Raspberry Pi Relay Controller.
# - Consulta o catalogo fleet.json ou GitHub Releases
# - Nao depende de repositorio Git local (funciona com bytecode .pyc protegido)
# - Preserva intacto o config.json local (credenciais e pinos do cliente)
# - Possui backup automatico e rollback caso o daemon falhe no healthcheck
# -----------------------------------------------------------------------------

set -e

# Determinar dinamicamente o diretorio da aplicao com base na localizacao deste script
CURRENT_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(cd "$CURRENT_SCRIPT_DIR/.." && pwd)"
SERVICE_NAME="relay-controller"
CONFIG_FILE="$APP_DIR/config.json"
BACKUP_DIR="$APP_DIR/backup_last_stable"
TMP_DOWNLOAD_DIR="/tmp/kwiek_update_$$"

# Verificar se executando no diretorio correto
cd "$APP_DIR"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Erro: config.json nao encontrado em $CONFIG_FILE"
    exit 1
fi

# Exportar bin/ para o PYTHONPATH para que os comandos python locais encontrem os modulos
export PYTHONPATH="$APP_DIR/bin:$PYTHONPATH"

# 1. Extrair configuracoes locais via python
CURRENT_VERSION=$(./venv/bin/python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('version', '1.0.0'))")
GITHUB_REPO=$(./venv/bin/python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('github_repo', 'eijuito/kwiek-autogate'))")
HWID=$(./venv/bin/python3 -c "import license_validator; print(license_validator.get_hardware_id())")
SSH_REPO_URL="git@github.com:${GITHUB_REPO}.git"

echo "=== Verificador de Atualizacoes Kwiek Autogate ==="
echo "Data: $(date)"
echo "Hardware ID: $HWID"
echo "Versao Atual: v$CURRENT_VERSION"
echo "repositorio SSH: $SSH_REPO_URL"

# 2. Consultar o catalogo de frotas (fleet.json) no GitHub via SSH (Deploy Key)
echo "Consultando autorizacao de versao no GitHub (via SSH Deploy Key)..."

mkdir -p "$TMP_DOWNLOAD_DIR"

# Baixar o fleet.json usando git clone superficial (--depth 1) via SSH
FLEET_JSON=""
if git clone --depth 1 --no-checkout "$SSH_REPO_URL" "$TMP_DOWNLOAD_DIR/fleet_repo" 2>/dev/null; then
    cd "$TMP_DOWNLOAD_DIR/fleet_repo"
    git checkout HEAD -- fleet.json 2>/dev/null || true
    if [ -f "fleet.json" ]; then
        FLEET_JSON=$(cat fleet.json)
    fi
    cd "$APP_DIR"
fi

if [ -n "$FLEET_JSON" ]; then
    # Extrair versao permitida para este HWID especifico no fleet.json
    TARGET_VERSION=$(./venv/bin/python3 -c "
import json
data = json.loads('''$FLEET_JSON''')
hwid = '$HWID'
licenses = data.get('licenses', {})
if hwid in licenses:
    print(licenses[hwid].get('target_version', '$CURRENT_VERSION'))
else:
    print(data.get('default_version', '$CURRENT_VERSION'))
")
else
    # Fallback: consultar ultima tag Git via SSH
    echo "Consultando tags disponiveis via SSH..."
    LATEST_TAG=$(git ls-remote --tags --refs "$SSH_REPO_URL" | awk -F/ '{print $3}' | grep -E '^v[0-9]+' | sort -V | tail -n 1)
    TARGET_VERSION=$(echo "$LATEST_TAG" | sed 's/^v//')
fi

if [ -z "$TARGET_VERSION" ]; then
    echo "Nao foi possivel determinar a versao de destino via SSH. Abortando com seguranca."
    rm -rf "$TMP_DOWNLOAD_DIR"
    exit 0
fi

echo "Versao Alvo Autorizada: v$TARGET_VERSION"

# 3. Comparar versoes
UPDATE_NEEDED=$(./venv/bin/python3 -c "
import license_validator
target = '$TARGET_VERSION'
current = '$CURRENT_VERSION'
if not license_validator.is_version_allowed(target, current):
    print('YES')
else:
    print('NO')
")

if [ "$UPDATE_NEEDED" != "YES" ]; then
    echo "O dispositivo ja esta na versao mais recente autorizada (v$CURRENT_VERSION)."
    rm -rf "$TMP_DOWNLOAD_DIR"
    exit 0
fi

echo -e "\nNova versao autorizada detectada: v$CURRENT_VERSION -> v$TARGET_VERSION"

# 4. Baixar versao pre-compilada da tag de distribuicao via SSH
echo "Baixando versao compilada v$TARGET_VERSION via SSH (Deploy Key)..."
mkdir -p "$TMP_DOWNLOAD_DIR/release"
git clone --depth 1 --branch "v$TARGET_VERSION-dist" "$SSH_REPO_URL" "$TMP_DOWNLOAD_DIR/release" 2>/dev/null || \
git clone --depth 1 --branch "client-dist" "$SSH_REPO_URL" "$TMP_DOWNLOAD_DIR/release"

# 5. Criar backup da versao atual antes de aplicar
echo "Criando backup de seguranca em $BACKUP_DIR..."
rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp -r templates static bin config.json "$BACKUP_DIR/" 2>/dev/null || true

# 6. Atualizar binarios em bin/ diretamente a partir da distribuicao (sem fontes)
echo "Atualizando binarios compilados em bin/..."
mkdir -p "$APP_DIR/bin"
cd "$TMP_DOWNLOAD_DIR/release"

# Copiar binarios pre-compilados direto para bin/
if [ -d "bin" ]; then
    cp -r bin/* "$APP_DIR/bin/"
fi

# Copiar assets estaticos, templates e deploy
cp -r templates static "$APP_DIR/" 2>/dev/null || true
cp -r deploy/*.sh "$APP_DIR/deploy/" 2>/dev/null || true
cd "$APP_DIR"

# Limpeza absoluta: nenhuma pasta de desenvolvimento, testes ou fontes
rm -rf "$APP_DIR/src" "$APP_DIR/tests" "$APP_DIR/tools" "$APP_DIR/docs" "$APP_DIR/.git" "$APP_DIR/.github" "$APP_DIR/.gemini" "$APP_DIR/__pycache__"
rm -f "$APP_DIR"/*.py "$APP_DIR"/*.pyc 2>/dev/null || true
rm -f "$APP_DIR/README.md" "$APP_DIR/CHANGELOG.md" "$APP_DIR/.gitignore" "$APP_DIR/requirements.txt" "$APP_DIR/fleet.json"

# Atualizar versao no config.json do cliente
./venv/bin/python3 -c "
import json
cfg_path = '$CONFIG_FILE'
with open(cfg_path, 'r') as f:
    d = json.load(f)
d['version'] = '$TARGET_VERSION'
with open(cfg_path, 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
"

# 7. Atualizar dependencias se requirements.txt mudou
if [ -f "requirements.txt" ]; then
    echo "Verificando dependencias Python..."
    ./venv/bin/pip install -q -r requirements.txt || true
fi

# Limpar temporarios
rm -rf "$TMP_DOWNLOAD_DIR"

# 8. Reiniciar o servico do daemon
echo "Reiniciando servico $SERVICE_NAME..."
sudo systemctl restart ${SERVICE_NAME}.service

# 9. Healthcheck pos-atualizacao (Verificacao de falha com rollback)
echo "Aguardando servico iniciar (Healthcheck)..."
HEALTHY=false

for i in {1..15}; do
    sleep 1
    # Consulta endpoint aberto e dedicado /api/health (independe de senhas ou usuarios)
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:8000/api/health" || echo "000")
    if [ "$HTTP_CODE" = "200" ]; then
        HEALTHY=true
        break
    fi
done

if [ "$HEALTHY" = true ]; then
    echo -e "\n=== Atualizao para v$TARGET_VERSION concluida com sucesso! ==="
else
    echo -e "\nAVISO CRITICO: O servico no respondeu apos o update! Iniciando Rollback automatico..."
    cp -r "$BACKUP_DIR/"* "$APP_DIR/"
    sudo systemctl restart ${SERVICE_NAME}.service
    echo "Rollback concludo. A versao anterior foi restaurada."
    exit 1
fi
