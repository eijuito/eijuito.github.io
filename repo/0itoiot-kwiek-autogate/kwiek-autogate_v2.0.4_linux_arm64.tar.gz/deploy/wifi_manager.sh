#!/bin/bash
# -----------------------------------------------------------------------------
# wifi_manager.sh
# Gerenciador inteligente de conectividade Wi-Fi e Hotspot de Fallback.
# - Verifica se o Raspberry Pi obteve conexao com a rede/internet (Ethernet ou Wi-Fi)
# - Se nao houver conectividade apos o timeout, ativa modo Ponto de Acesso (Hotspot)
# - Utiliza o NetworkManager (nmcli), nativo do Raspberry Pi OS.
# -----------------------------------------------------------------------------

set -e

HOTSPOT_CON_NAME="Kwiek-Setup-AP"
HOTSPOT_SSID="Kwiek-Autogate-Setup"
HOTSPOT_PASSWORD="kwieksetup123"
CHECK_TIMEOUT=35
CHECK_INTERVAL=5

echo "=== Kwiek Autogate Wi-Fi & Hotspot Manager ==="
echo "Verificando conectividade de rede (Timeout: ${CHECK_TIMEOUT}s)..."

elapsed=0
is_connected=false

while [ $elapsed -lt $CHECK_TIMEOUT ]; do
    # Verifica se ha qualquer conexao ativa com gateway/internet (Ethernet ou Wi-Fi)
    if nmcli -t -f RUNNING general | grep -q "running"; then
        # Verifica se alguma interface tem IP atribuido e conectividade
        STATE=$(nmcli -t -f CONNECTIVITY general || echo "none")
        if [ "$STATE" = "full" ] || [ "$STATE" = "limited" ]; then
            is_connected=true
            break
        fi
    fi
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    echo "Aguardando rede... (${elapsed}s/${CHECK_TIMEOUT}s)"
done

if [ "$is_connected" = true ]; then
    echo "Dispositivo conectado com sucesso a rede. Modo Hotspot nao e necessario."
    # Se o perfil de hotspot ainda estiver ativo por algum motivo, desativa
    if nmcli connection show --active | grep -q "$HOTSPOT_CON_NAME"; then
        echo "Desativando Hotspot previo..."
        nmcli connection down "$HOTSPOT_CON_NAME" || true
    fi
    exit 0
fi

echo "Nenhuma rede ou internet detectada. Iniciando Ponto de Acesso (Hotspot)..."

# Verificar se conexao hotspot ja existe
if ! nmcli connection show "$HOTSPOT_CON_NAME" > /dev/null 2>&1; then
    echo "Criando perfil de Hotspot '$HOTSPOT_SSID'..."
    nmcli connection add type wifi ifname wlan0 con-name "$HOTSPOT_CON_NAME" autoconnect no ssid "$HOTSPOT_SSID"
    nmcli connection modify "$HOTSPOT_CON_NAME" 802-11-wireless.mode ap 802-11-wireless.band bg
    nmcli connection modify "$HOTSPOT_CON_NAME" ipv4.method shared ipv4.addresses 192.168.4.1/24
    nmcli connection modify "$HOTSPOT_CON_NAME" wifi-sec.key-mgmt wpa-psk
    nmcli connection modify "$HOTSPOT_CON_NAME" wifi-sec.psk "$HOTSPOT_PASSWORD"
fi

echo "Ativando Ponto de Acesso: $HOTSPOT_SSID..."
nmcli connection up "$HOTSPOT_CON_NAME" || true
echo "Ponto de Acesso ativo em 192.168.4.1. SSID: $HOTSPOT_SSID | Senha: $HOTSPOT_PASSWORD"
