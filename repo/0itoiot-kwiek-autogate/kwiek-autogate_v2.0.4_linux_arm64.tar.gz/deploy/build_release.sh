#!/bin/bash
# -----------------------------------------------------------------------------
# build_release.sh
# Creates compiled versioned release packages stored in the 'releases/' folder.
# Used by developers/CI to archive release history and track old defects.
# -----------------------------------------------------------------------------

set -e

# Configuration
PROJECT_NAME="kwiek-autogate"
RELEASE_DIR="releases"
TEMP_BUILD_DIR="temp_build"

echo "=== Starting Release Package Build ==="

# 1. Ensure config.json exists
if [ ! -f "config.json" ]; then
    echo "Error: config.json missing. Cannot determine version."
    exit 1
fi

# 2. Extract version from config.json using python
VERSION=$(python3 -c "import json; print(json.load(open('config.json'))['version'])")
echo "Building release package for version: v$VERSION"

# 3. Create releases output directory
mkdir -p "$RELEASE_DIR"

# 4. Create and clean temporary build environment
rm -rf "$TEMP_BUILD_DIR"
mkdir -p "$TEMP_BUILD_DIR"

# 5. Copy necessary files to build directory
echo "Copying project files..."
cp -r static templates docs requirements.txt config.json "$TEMP_BUILD_DIR/"
cp main.py relay_controller.py config.py "$TEMP_BUILD_DIR/"

# Create deploy dir in temporary build and copy install.sh
mkdir -p "$TEMP_BUILD_DIR/deploy"
cp deploy/install.sh "$TEMP_BUILD_DIR/deploy/"

# 6. Compile Python files in the build directory to bytecode (.pyc)
echo "Compiling Python source code..."
python3 -m compileall -b "$TEMP_BUILD_DIR"

# 7. Remove all raw source (.py) files from the build directory
echo "Removing raw Python source files..."
find "$TEMP_BUILD_DIR" -name "*.py" -type f -delete

# 8. Archive the build folder into a tarball
ARCHIVE_NAME="${PROJECT_NAME}-v${VERSION}.tar.gz"
echo "Creating compressed archive: ${RELEASE_DIR}/${ARCHIVE_NAME}..."
tar -czf "${RELEASE_DIR}/${ARCHIVE_NAME}" -C "$TEMP_BUILD_DIR" .

# 9. Clean up temporary build environment
rm -rf "$TEMP_BUILD_DIR"

echo -e "\n=== Release Package v$VERSION Built Successfully! ==="
echo "Archive saved to: ${RELEASE_DIR}/${ARCHIVE_NAME}"
